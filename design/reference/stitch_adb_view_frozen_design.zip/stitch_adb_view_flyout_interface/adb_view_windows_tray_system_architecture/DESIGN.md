---
name: ADB View Windows Tray & System Architecture
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#bfc7d2'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#89929b'
  outline-variant: '#3f4850'
  surface-tint: '#93ccff'
  primary: '#93ccff'
  on-primary: '#003351'
  primary-container: '#3198dc'
  on-primary-container: '#002c47'
  inverse-primary: '#006398'
  secondary: '#b7c8e1'
  on-secondary: '#213145'
  secondary-container: '#3a4a5f'
  on-secondary-container: '#a9bad3'
  tertiary: '#4edea3'
  on-tertiary: '#003824'
  tertiary-container: '#00a572'
  on-tertiary-container: '#00311f'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#cce5ff'
  primary-fixed-dim: '#93ccff'
  on-primary-fixed: '#001d31'
  on-primary-fixed-variant: '#004b73'
  secondary-fixed: '#d3e4fe'
  secondary-fixed-dim: '#b7c8e1'
  on-secondary-fixed: '#0b1c30'
  on-secondary-fixed-variant: '#38485d'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  headline-lg:
    fontFamily: Geist
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0em
  body-lg:
    fontFamily: Geist
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  body-md:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0em
  body-sm:
    fontFamily: Geist
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 14px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: -0.02em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: -0.02em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 12px
    letterSpacing: -0.01em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 0.5rem
  margin: 0.75rem
  space-xs: 0.125rem
  space-sm: 0.25rem
  space-md: 0.5rem
  space-lg: 0.75rem
  space-xl: 1rem
---

## Brand & Style
This design system governs the visual identity, developer utility tooling, and system-level iconography for ADB (Android Debug Bridge) desktop monitor environments and Windows 11 system integration. 

Rooted in Fluent 2 principles, the style blends technical utility with desktop precision. It treats Android device state diagnostics not as abstract web UI, but as an intrinsic Windows native service. Visual elements emphasize crisp vector geometry, sub-pixel stroke alignment, and restrained micro-surfaces. The aesthetic is calm, highly engineered, and low-friction, prioritizing at-a-glance legibility across dense system tray flyouts, taskbar icons, and multi-device inspect panels.

## Colors
The palette utilizes a slate foundation paired with laser-focused semantic indicators. Backgrounds rely on Windows 11 mica/smoke dark tones rather than pitch blacks, maintaining neutral contrast across nested hardware status panels.

- **Primary (`#0284c7` - Sky):** Signals active bridge connection, active transport streams, selected device instances, and primary actionable states.
- **Secondary (`#64748b` - Slate):** Anchors secondary controls, inactive hardware registers, port indicators, and structural dividers.
- **Tertiary (`#10b981` - Emerald):** Reserved strictly for verified device authorization, online daemon health, and zero-error telemetry.
- **Neutral (`#0f172a` - Deep Slate):** Core canvas background ensuring high signal-to-noise ratio when reading diagnostic output.

### Semantic Status Tokens
- **Connected / Online:** `#10b981` (Emerald)
- **Authorizing / Unstable / Stalled:** `#f59e0b` (Amber)
- **Offline / Deadlock / Error:** `#ef4444` (Crimson)
- **Inspecting / Bridge Sync:** `#0284c7` (Sky)

## Typography
Typography is split into two specialized roles: structural interface labels (Geist) and hardware telemetry data (JetBrains Mono). 

- **Geist:** Provides clinical clarity for flyout headers, menu items, device model identifiers, and modal actions without visual distortion at compact 11px–14px sizes.
- **JetBrains Mono:** Mandated for IP endpoints, serial hashes, ADB port allocations (`:5555`), logcat streams, and transfer rate telemetry. Numbers are tabular to avoid jitter during real-time updates.

## Layout & Spacing
The layout adheres strictly to compact desktop paradigms. The system tray flyout is fixed-dimension (340px to 380px width) with an internal micro-grid based on a strict 4px coordinate scale (`0.25rem`).

- **Grid Alignment:** All visual boundaries, margins, and separator horizontal rules align with full pixel boundaries to prevent anti-aliasing fuzz on standard DPI displays.
- **Desktop Density:** Spacing tokens prioritize information density, employing `space-sm` (4px) and `space-md` (8px) internally within lists and device cards, while `margin` (12px) guards the primary window and system tray flyout boundaries.

## Elevation & Depth
Depth mimics the native Windows 11 Acrylic and Mica composite surfaces. Elevation does not use dramatic, spreading shadows; it relies on structured translucent layering combined with 1px hairline inner borders.

- **Base Layer (Taskbar / Background):** Solid neutral `#0f172a` or native Acrylic (`#0f172acc` with `backdrop-filter: blur(20px)`).
- **Surface Elevation 1 (Cards, Flyout Panels):** `#1e293b` with a 1px border of `rgba(255, 255, 255, 0.08)`.
- **Surface Elevation 2 (Hover States, Popovers):** `#334155` with a subtle directional drop shadow: `0 4px 12px rgba(0, 0, 0, 0.35)`.
- **Icon Rendering Surfaces:** Icons on dark backgrounds avoid baked raster drop shadows. Optical depth inside large icon art (64px, 256px) is achieved through subtle directional vector gradients (linear 45° tint to shade). Small scales (16px to 32px) use 100% flat vector fills with sharp cutout counter-spaces.

## Shapes
Shape rules align with Fluent 2 desktop geometry:
- **Base Components (Buttons, Chips, Menus):** `0.25rem` (4px) border radius.
- **Containers & Flyout Shells (`rounded-lg`):** `0.5rem` (8px) radius.
- **Icon Mask Geometry:** Rounded corners within icon silhouettes scale according to the optical icon grid rules:
  - 16px/20px icons: 1px internal/external corner radius.
  - 24px/32px icons: 2px corner radius.
  - 64px+ icons: 4px–8px corner radius.

## Components

### System Tray & Application Iconography (Optical Scaling Grid)
All icons must be authored on exact pixel-snapped target artboards:
- **16px (Tray Default):** 1px stroke or filled silhouette. Maximum detail reduction: internal screen details are dropped, retaining only pure chassis outline and semantic badge dot (3px diameter).
- **20px & 24px (Taskbar / Compact Menus):** 1.5px stroke weight. Hardware details (USB-C port silhouette, volume toggle indent) become legible.
- **32px (Quick Settings & Density Views):** 2px stroke weight or composite dual-tone fill (`opacity: 0.2` for secondary fields).
- **64px (Device Info Headers):** High-fidelity vector layout featuring connector geometry, status LED arrays, and battery tier markings.
- **256px (App Launcher / Store Art):** Detailed Fluent composition with multi-stop radial highlights and hardware surface beveling.

### Device Cards
Compact rectangular blocks housed inside the system tray flyout.
- Contains: Model Name (`headline-sm`), Connection Transport (`label-md` e.g., `WIFI:5555` or `USB:3.1`), and State Chip.
- Background: Surface Elevation 1 (`#1e293b`), transitioning to `#334155` on cursor hover.

### Status Indicators & Chips
- Status badge dots: 6px solid circles. Connected uses `#10b981`, with an optional animated radar pulse ring when actively debugging.
- Transport Chips: Monospace text, 2px vertical padding, 6px horizontal padding, background `rgba(255, 255, 255, 0.05)`, text `#64748b`.

### Action Buttons
- Height: 24px (compact tray toolbar) or 32px (dialog views).
- Primary Button: Solid `#0284c7`, text `#ffffff`, hover `#0369a1`.
- Subtle/Ghost Tool Buttons: Transparent background, `#64748b` icon/text, hover background `rgba(255, 255, 255, 0.08)`, active text `#f8fafc`.

### Log & Telemetry Rows
Monospaced list items with an alternating row tint (`rgba(255, 255, 255, 0.02)`), zero border radius, and fixed 18px height per entry. Error levels tint the entire text line (`#ef4444`), while standard dumps remain muted slate (`#94a3b8`).